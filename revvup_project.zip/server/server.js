require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { OpenAIApi, Configuration } = require('openai');

const app = express();
app.use(bodyParser.json({ limit: '1mb' }));

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

const DATA_FILE = path.join(__dirname, 'data.json');
let DB = { reviews: [], businesses: [] };
try {
  if (fs.existsSync(DATA_FILE)) {
    DB = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } else {
    fs.writeFileSync(DATA_FILE, JSON.stringify(DB, null, 2));
  }
} catch (err) {
  console.error('Failed to read/write data file', err);
}

function persist() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(DB, null, 2));
}

app.post('/api/moderate', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'text required' });

    const modResp = await openai.createModeration({
      model: 'omni-moderation-latest',
      input: text,
    });

    const results = modResp?.data?.results?.[0] ?? null;
    return res.json({ success: true, results });
  } catch (err) {
    console.error('moderation error', err?.response?.data ?? err.message);
    return res.status(500).json({ error: 'moderation failed', details: err?.message || err });
  }
});

app.post('/api/reviews', async (req, res) => {
  try {
    const { businessId, userId, userName, rating, text } = req.body;
    if (!businessId || !userId || !rating) return res.status(400).json({ error: 'missing fields' });

    const modResp = await openai.createModeration({
      model: 'omni-moderation-latest',
      input: text || '',
    });
    const mod = modResp?.data?.results?.[0] || {};
    const flagged = !!mod.flagged;

    const review = {
      id: `r_${Math.random().toString(36).slice(2,9)}`,
      businessId,
      userId,
      userName,
      rating,
      text,
      createdAt: new Date().toISOString(),
      flagged,
      moderation: mod,
    };

    DB.reviews.unshift(review);
    persist();

    return res.json({ success: true, review });
  } catch (err) {
    console.error('create review err', err?.response?.data ?? err.message);
    return res.status(500).json({ error: 'failed to create review', details: err?.message || err });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`RevvUp backend listening on ${PORT}`);
});
