import React, { useState, useEffect } from 'react';

function uid(prefix='id'){return `${prefix}_${Math.random().toString(36).slice(2,9)}`;}
function now(){return new Date().toISOString();}

export default function App(){
  const [businesses, setBusinesses] = useState([
    { id:'b_01', name:'Café Kapi', address:'10 MG Road, Bengaluru', category:'Cafe', description:'Cozy cafe serving filter coffee.', photos:[], createdAt: now() },
    { id:'b_02', name:'Masala Dabba', address:'Sector 18, Noida', category:'Restaurant', description:'Homestyle North Indian food.', photos:[], createdAt: now() }
  ]);
  const [reviews, setReviews] = useState([]);
  const [selected, setSelected] = useState(null);
  const [user] = useState({ id:'u_demo', name:'Demo User' });
  const [query, setQuery] = useState('');

  useEffect(()=> {
    // try to load reviews from backend
    fetch('/api/reviews').catch(()=>{});
  },[]);

  async function postReview(businessId, rating, text){
    try {
      const resp = await fetch('/api/reviews', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ businessId, userId: user.id, userName: user.name, rating, text })
      });
      const data = await resp.json();
      if(data?.success){
        setReviews(r=>[data.review, ...r]);
        alert('Review posted');
      } else {
        alert('Failed to post review');
      }
    } catch(e){
      alert('Network error');
    }
  }

  return (
    <div style={{maxWidth:960, margin:'24px auto', padding:12}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1 style={{color:'#4c51bf'}}>RevvUp</h1>
        <div>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." />
        </div>
      </header>

      <main style={{display:'flex', gap:16, marginTop:16}}>
        <section style={{flex:2}}>
          {businesses.filter(b=> (b.name+b.address+b.description).toLowerCase().includes(query.toLowerCase())).map(b=>(
            <div key={b.id} style={{background:'#fff', padding:12, borderRadius:8, marginBottom:12}}>
              <div style={{display:'flex', justifyContent:'space-between'}}>
                <div>
                  <strong style={{fontSize:18}}>{b.name}</strong>
                  <div style={{fontSize:13, color:'#666'}}>{b.category} • {b.address}</div>
                </div>
                <div>
                  <button onClick={()=>{setSelected(b)}}>Open</button>
                </div>
              </div>
              <p style={{marginTop:8}}>{b.description}</p>
            </div>
          ))}
        </section>

        <aside style={{flex:1}}>
          <div style={{background:'#fff', padding:12, borderRadius:8}}>
            <h4>About RevvUp</h4>
            <p style={{fontSize:13, color:'#666'}}>Demo site for local business discovery, India-focused.</p>
          </div>
        </aside>
      </main>

      {selected && (
        <div style={{maxWidth:800, margin:'20px auto', background:'#fff', padding:16, borderRadius:8}}>
          <h3>{selected.name}</h3>
          <div style={{color:'#666'}}>{selected.address} • {selected.phone}</div>
          <p>{selected.description}</p>

          <h4>Write a review</h4>
          <ReviewForm onSubmit={(rating,text)=>postReview(selected.id,rating,text)} />
          <h4 style={{marginTop:12}}>Reviews</h4>
          {reviews.filter(r=>r.businessId===selected.id).map(r=>(
            <div key={r.id} style={{borderTop:'1px solid #eee', paddingTop:8, marginTop:8}}>
              <div><strong>{r.userName}</strong> • {r.rating}★</div>
              <div style={{fontSize:13}}>{r.text}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ReviewForm({onSubmit}){
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  return (
    <div style={{display:'grid', gap:8}}>
      <select value={rating} onChange={e=>setRating(Number(e.target.value))}>
        <option value={5}>5 - Excellent</option>
        <option value={4}>4 - Very good</option>
        <option value={3}>3 - Good</option>
        <option value={2}>2 - Not great</option>
        <option value={1}>1 - Poor</option>
      </select>
      <textarea value={text} onChange={e=>setText(e.target.value)} rows={4} placeholder="Write your review..." />
      <div>
        <button onClick={()=>{ if(text.trim().length<5){alert('Write more');return;} onSubmit(rating,text); setText(''); }}>Post Review</button>
      </div>
    </div>
  );
}
