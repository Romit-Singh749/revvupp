# RevvUp (Demo)

This repository contains a demo RevvUp project (frontend + backend) for a Yelp-like site focused on India.

## Structure
- `server/` - Express backend that provides moderation via OpenAI Moderation API and a reviews endpoint.
- `frontend/` - React frontend demo (basic) that posts reviews to the backend.

## Quickstart (local)
1. Backend:
   - `cd server`
   - copy `.env.example` to `.env` and set `OPENAI_API_KEY`
   - `npm install`
   - `npm run dev`

2. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm start`

Frontend proxies `/api` requests to `http://localhost:4000` (see `frontend/package.json` proxy).

## Deploying & GitHub
- Create a GitHub repo and push this project.
- For preview:
  - Deploy frontend to Vercel/Netlify (connect GitHub).
  - Deploy backend to Render/Heroku or use Vercel Serverless Functions.
  - Set `OPENAI_API_KEY` in backend's env vars.

## Notes
- This is a demo. For production, add real DB, secure auth, image storage, rate-limiting, and proper moderation policy.
